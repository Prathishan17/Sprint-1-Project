import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import joblib
import sys

# 1. Load Data
try:
    data = pd.read_excel("students_data.xlsx", header=None)
except Exception as e:
    print(f"Error loading file: {e}")
    sys.exit()

# 2. Extract and Rename Columns
data = data.iloc[:, :5]
data.columns = ['tamil', 'english', 'maths', 'science', 'social']

# 3. Force Numeric Conversion
for col in data.columns:
    data[col] = pd.to_numeric(data[col], errors='coerce')

# 4. Handle Missing Values (Crucial Fix)
data = data.fillna(data.mean())
data = data.fillna(0)

# 5. Features and Target
X = data[['tamil', 'english', 'maths', 'science']]
y = data['social']

# 6. Final check: If X still has NaNs, the model will crash. 
X = X.dropna()
y = y.loc[X.index] 

# 7. Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# 8. Train Model
model = LinearRegression()
model.fit(X_train, y_train)

# 9. Save
joblib.dump(model, "student_performance_model.pkl")
print("Success: ML Model trained and saved successfully!")