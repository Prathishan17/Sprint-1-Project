from flask import Flask, render_template, request, redirect, session, url_for, g, flash, send_file
import pandas as pd
import sqlite3
import os
import joblib
import numpy as np

app = Flask(__name__)
app.secret_key = "your_secret_key_here"

# Load ML model - ensure student_performance_model.pkl exists in the folder
try:
    model = joblib.load("C:\My Visual Studio Folder\student_performance\student_performance_model.pkl")
except Exception as e:
    print(f"Warning: Model not found. Prediction will fail. Error: {e}")

# --- DATABASE HELPERS ---
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect("database.db", check_same_thread=False)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

# --- ROUTES ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/student')
@app.route('/student_options')
def student_option_page():
    return render_template('student_options.html')

# --- student Login Route ---

@app.route('/student/login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        student_id = request.form.get('id')
        db = get_db()
        student = db.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()

        if student:
            session['student'] = student_id
            return redirect(url_for('view_result_page'))

        return render_template('student_login.html', error="Invalid Student ID")
    return render_template('student_login.html')

# --- student view room Route ---

@app.route('/student/view_room', methods=['GET', 'POST'])
def view_room_page():
    room = None
    if request.method == 'POST':
        student_id = request.form.get('student_id')
        db = get_db()
        room = db.execute("""
            SELECT s.name, s.id, r.block_name, r.room_number
            FROM students s
            LEFT JOIN room_allocations r ON s.id = r.student_id
            WHERE s.id = ?
        """, (student_id,)).fetchone()
    return render_template('view_room.html', room=room)

# --- student view reult Route ---

@app.route('/student/view_result')
def view_result_page():
    if 'student' not in session:
        return redirect(url_for('student_login'))

    db = get_db()
    student_id = session['student']
    student_data = db.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()

    if not student_data:
        flash("Student record not found.")
        return redirect(url_for('student_login'))

    avg = student_data['average']
    if avg >= 90: feedback = "Excellent! Keep it up!"
    elif avg >= 75: feedback = "Very Good. Aim for excellence!"
    elif avg >= 60: feedback = "Good. Keep improving."
    elif avg >= 40: feedback = "Fair. Try harder next time."
    else: feedback = "Needs Improvement. Don't give up!"

    return render_template('view_result.html', student=student_data, feedback=feedback)

#-- teacher route --

@app.route('/teacher')
def teacher_page():
    return render_template('teacher_options.html')

# --- teacher/register Route ---

@app.route('/teacher/register', methods=['GET', 'POST'])
def teacher_register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        try:
            conn = get_db()
            conn.execute("INSERT INTO teachers (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            return redirect('/teacher/login')
        except sqlite3.IntegrityError:
            return render_template('teacher_register.html', error="Username already taken.")
    return render_template('teacher_register.html')

# --- teacher/login Route ---

@app.route('/teacher/login', methods=['GET', 'POST'])
def teacher_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        db = get_db()
        teacher = db.execute("SELECT * FROM teachers WHERE username = ? AND password = ?", (username, password)).fetchone()
        if teacher:
            session['teacher'] = username
            return redirect('/teacher/dashboard')
        return render_template('teacher_login.html', error="Invalid credentials")
    return render_template('teacher_login.html')

# --- teacher/dashboard Route ---

@app.route('/teacher/dashboard')
def teacher_dashboard():
    return render_template('teacher_dashboard.html')

# --- Add student Route ---

@app.route('/add', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        student_id = request.form.get('id')
        name = request.form.get('name')
        regno = request.form.get('regno')
        tamil = int(request.form.get('tamil'))
        english = int(request.form.get('english'))
        maths = int(request.form.get('maths'))
        science = int(request.form.get('science'))
        social = int(request.form.get('social'))

        total = tamil + english + maths + science + social
        average = round(total / 5, 2)

        # ---------------- ML PREDICTION ----------------
        # Using 4 subjects to predict the 5th based on our model logic
        input_feats = [[tamil, english, maths, science]]
        predicted_social = model.predict(input_feats)[0]
        result = "Pass" if (predicted_social >= 35 and min(tamil, english, maths, science) >= 35) else "Fail"
        # ------------------------------------------------

        db = get_db()
        db.execute('''
            INSERT INTO students (id, name, regno, tamil, english, maths, science, social, total, average, result)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (student_id, name, regno, tamil, english, maths, science, social, total, average, result))
        db.commit()
        return redirect(url_for('all_students'))

    return render_template('add.html')

# --- student all records Route ---

@app.route('/all', methods=['GET', 'POST'])
def all_students():
    db = get_db()
    if request.method == 'POST':
        student_id = request.form.get('student_id')
        students = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchall() if student_id else db.execute("SELECT * FROM students").fetchall()
    else:
        students = db.execute("SELECT * FROM students").fetchall()
    return render_template('all.html', students=students)

# --- edit Route ---

@app.route('/edit/<id>', methods=['GET', 'POST'])
def edit_student(id):
    db = get_db()
    if request.method == 'POST':
        name, regno = request.form.get('name'), request.form.get('regno')
        tamil, english, maths = int(request.form.get('tamil')), int(request.form.get('english')), int(request.form.get('maths'))
        science, social = int(request.form.get('science')), int(request.form.get('social'))

        total = tamil + english + maths + science + social
        average = round(total / 5, 2)
        result = "Fail" if min(tamil, english, maths, science, social) < 35 else "Pass"

        db.execute("""
            UPDATE students SET name=?, regno=?, tamil=?, english=?, maths=?, science=?, social=?, 
            total=?, average=?, result=? WHERE id=?
        """, (name, regno, tamil, english, maths, science, social, total, average, result, id))
        db.commit()
        return redirect('/all')
    
    student = db.execute("SELECT * FROM students WHERE id=?", (id,)).fetchone()
    return render_template('edit.html', student=student)

# --- delete Route ---

@app.route('/delete/<id>')
def delete_student(id):
    db = get_db()
    db.execute("DELETE FROM students WHERE id=?", (id,))
    db.commit()
    return redirect('/all')

# --- bar-chart Route ---

@app.route('/bar-chart')
def bar_chart():
    db = get_db()
    data = db.execute('SELECT SUM(tamil), SUM(english), SUM(maths), SUM(science), SUM(social) FROM students').fetchone()
    subjects = ['Tamil', 'English', 'Maths', 'Science', 'Social']
    return render_template('bar_chart.html', subjects=subjects, totals=list(data) if data[0] is not None else [0,0,0,0,0])
# --- download excel Route ---
@app.route('/download-excel')
def download_excel():
    conn = sqlite3.connect('database.db')
    df = pd.read_sql_query("SELECT * FROM students", conn)
    conn.close()
    file_path = "students_data.xlsx"
    df.to_excel(file_path, index=False)
    return send_file(file_path, as_attachment=True, download_name='Student_Records.xlsx')

# --- allocate room Route ---
@app.route('/allocate_room')
def allocate_room_page():
    db = get_db()
    students = db.execute('''
        SELECT s.id, s.name, s.id AS student_id, r.block_name, r.room_number 
        FROM students s LEFT JOIN room_allocations r ON s.id = r.student_id
    ''').fetchall()
    return render_template('allocate_room.html', students=students)

@app.route('/save_room', methods=['POST'])
def save_room():
    student_id, block, room = request.form.get('student_id'), request.form.get('block_name'), request.form.get('room_number')
    db = get_db()
    db.execute("INSERT OR REPLACE INTO room_allocations (student_id, block_name, room_number) VALUES (?, ?, ?)", (student_id, block, room))
    db.commit()
    flash("Room Allocated Successfully", "success")
    return redirect('/allocate_room')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)